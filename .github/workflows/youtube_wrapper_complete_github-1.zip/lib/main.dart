import 'package:flutter/material.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const WrapperApp());

class WrapperApp extends StatelessWidget {
  const WrapperApp({super.key});

  @override
  Widget build(BuildContext context) {
    const red = Color(0xFFFF0033);
    return MaterialApp(
      title: 'YouTube Wrapper',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0F0F0F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: red,
          brightness: Brightness.dark,
          surface: const Color(0xFF181818),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F0F0F),
          surfaceTintColor: Colors.transparent,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _search = TextEditingController();
  String _videoId = 'aqz-KE-bpKQ'; // Public sample video; replace with a chosen video ID.
  late YoutubePlayerController _player;
  bool _showPlayer = false;

  @override
  void initState() {
    super.initState();
    _player = _makeController(_videoId);
  }

  YoutubePlayerController _makeController(String id) {
    return YoutubePlayerController.fromVideoId(
      videoId: id,
      autoPlay: false,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: true,
        strictRelatedVideos: true,
        enableCaption: true,
        playsInline: true,
        color: 'red',
      ),
    );
  }

  void _openVideo(String input) {
    final value = input.trim();
    final uri = Uri.tryParse(value);
    String? id;
    if (uri != null && (uri.host.contains('youtube.com') || uri.host == 'youtu.be')) {
      id = uri.queryParameters['v'];
      if (uri.host == 'youtu.be') {
        id = uri.pathSegments.isNotEmpty ? uri.pathSegments.first : null;
      }
      if (uri.pathSegments.contains('shorts')) {
        final index = uri.pathSegments.indexOf('shorts');
        if (index + 1 < uri.pathSegments.length) id = uri.pathSegments[index + 1];
      }
    } else if (RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(value)) {
      id = value;
    }
    if (id == null || !RegExp(r'^[A-Za-z0-9_-]{11}$').hasMatch(id)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Introdu un URL YouTube valid sau un ID de 11 caractere.')),
      );
      return;
    }
    setState(() {
      _videoId = id!;
      _player.close();
      _player = _makeController(_videoId);
      _showPlayer = true;
    });
    FocusScope.of(context).unfocus();
  }

  Future<void> _openGoogleSignInInfo() async {
    final uri = Uri.parse('https://accounts.google.com/');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  void dispose() {
    _search.dispose();
    _player.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Padding(
          padding: EdgeInsets.only(left: 14),
          child: Icon(Icons.smart_display, color: Color(0xFFFF0033), size: 30),
        ),
        leadingWidth: 48,
        title: const Text('YouTube Wrapper', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            tooltip: 'Cont Google (opțional)',
            onPressed: _openGoogleSignInInfo,
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            TextField(
              controller: _search,
              textInputAction: TextInputAction.go,
              onSubmitted: _openVideo,
              decoration: InputDecoration(
                hintText: 'Lipește un link YouTube sau ID-ul video',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  onPressed: () => _openVideo(_search.text),
                  icon: const Icon(Icons.arrow_forward),
                ),
                filled: true,
                fillColor: const Color(0xFF242424),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (_showPlayer) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: YoutubePlayer(
                  controller: _player,
                  aspectRatio: 16 / 9,
                ),
              ),
              const SizedBox(height: 12),
              Text('Video ID: $_videoId', style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              const Text(
                'Folosește comenzile playerului oficial. Disponibilitatea PiP și a redării în fundal depinde de dispozitiv, player și regulile YouTube.',
                style: TextStyle(color: Colors.white70),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF181818),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.play_circle_outline, size: 52, color: Color(0xFFFF0033)),
                    SizedBox(height: 16),
                    Text('Urmărește videoclipuri YouTube',
                        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Text('Lipește un link sau un ID de videoclip pentru a începe.'),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text('Acces rapid', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _QuickLink(
              icon: Icons.open_in_new,
              title: 'Deschide YouTube',
              subtitle: 'Căutare completă și funcțiile oficiale',
              onTap: () => launchUrl(Uri.parse('https://m.youtube.com/'),
                  mode: LaunchMode.externalApplication),
            ),
            _QuickLink(
              icon: Icons.picture_in_picture_alt,
              title: 'Picture-in-Picture',
              subtitle: 'Disponibilitatea depinde de suportul playerului și Android',
              onTap: () => _showInfo(context, 'PiP',
                  'AndroidManifest este configurat cu supportsPictureInPicture. Playerul încorporat poate să nu intre automat în PiP; este necesară testarea pe dispozitiv și respectarea politicilor YouTube.'),
            ),
            _QuickLink(
              icon: Icons.music_note,
              title: 'Redare în fundal',
              subtitle: 'Nu este garantată pentru playerul încorporat',
              onTap: () => _showInfo(context, 'Redare în fundal',
                  'Playerul oficial încorporat nu oferă o garanție generală de redare în fundal. Nu încerca să extragi fluxurile media sau să ocolești limitările YouTube. Pentru redarea oficială în fundal poate fi necesar YouTube Premium.'),
            ),
            const SizedBox(height: 16),
            const Text(
              'Notă: acest proiect este un starter open-source pentru interfață. Nu blochează reclame, nu extrage fluxuri video și nu implementează autentificarea Google; butonul de cont deschide pagina oficială Google.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickLink extends StatelessWidget {
  const _QuickLink({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        color: const Color(0xFF181818),
        child: ListTile(
          leading: Icon(icon, color: const Color(0xFFFF0033)),
          title: Text(title),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}

void _showInfo(BuildContext context, String title, String message) {
  showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Am înțeles')),
      ],
    ),
  );
}
