# YouTube Wrapper Flutter — build APK direct pe GitHub

Acest pachet include proiectul Flutter și workflow-ul GitHub Actions pentru a compila APK-ul în cloud. Nu este necesar Android Studio pe calculatorul tău.

## Pași rapizi

1. Creează un repository nou la https://github.com/new
2. Descarcă și dezarhivează acest pachet.
3. În repository, folosește **Add file → Upload files** și încarcă toate fișierele și folderele din acest pachet, inclusiv folderul ascuns `.github`.
4. Apasă **Commit changes**.
5. Deschide fila **Actions**. Dacă este dezactivată, apasă pentru activarea workflow-urilor.
6. Alege **Build Android APK** → **Run workflow**.
7. Așteaptă terminarea jobului. În pagina rulării, descarcă artifact-ul `youtube-wrapper-release-apk`.
8. Dezarhivează artifact-ul pentru a obține `app-release.apk`, apoi transferă APK-ul pe telefon și instalează-l.

## Dacă nu apare Actions
Verifică să existe fișierul `.github/workflows/build-apk.yml` în repository. În timpul încărcării prin browser, asigură-te că folderul `.github` nu a fost omis.

## Ce include
- Interfață Flutter dark
- Player YouTube încorporat
- Configurare Android PiP și canal nativ Kotlin de bază
- Workflow pentru compilare release APK

## Limitări
- Acesta este un starter de dezvoltare, nu o aplicație testată pe dispozitiv.
- Playerul oficial încorporat nu garantează PiP sau redarea în fundal în toate situațiile.
- Autentificarea Google reală necesită configurare OAuth separată; butonul actual deschide pagina Google.
- Nu blochează reclamele și nu ocolește restricțiile YouTube.
- APK-ul generat de workflow este pentru instalare/testare; publicarea pe Google Play necesită semnare și configurare suplimentară.
